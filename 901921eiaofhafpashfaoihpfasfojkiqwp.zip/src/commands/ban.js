/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const fs = require('fs');
const {
	MessageEmbed
} = require('discord.js');

module.exports = {
	name: 'ban',
	description: 'Bans the member from the server',
	usage: '',
	aliases: ['b'],
	example: 'ban Abdi',
	args: true,
  permission: 'BAN_MEMBERS',
	async execute(client, message, args, {config, Ticket}) {
    const member = message.mentions.members.first()
    if (member === message.member)
      return message.channel.send('You cannot ban yourself'); 
    if (!member.bannable)
      return message.channel.send('Provided member is not bannable');
 
    let reason = args.slice(1).join(' ');
    if (!reason) reason = '`No Reason Provided`';
    if (reason.length > 1024) reason = reason.slice(0, 1021) + '...';

    
    await member.ban({ days: 7, reason: `Banned By + ${message.author.tag} Reason: ${reason}` });

    const embed = new MessageEmbed()
      .setTitle('Ban Member')
      .setDescription(`${member} was successfully banned.`)
      .addField('Moderator', message.member, true)
      .addField('Member', member, true)
      .addField('Reason', reason)
      .setFooter(message.member.displayName,  message.author.displayAvatarURL({ dynamic: true }))
      .setTimestamp()
      .setColor(message.guild.me.displayHexColor);
    message.channel.send(embed);
        
    // Update mod log
 message.client.channels.fetch('745337461881962638').then(channel => channel.send(embed))
  }
};
