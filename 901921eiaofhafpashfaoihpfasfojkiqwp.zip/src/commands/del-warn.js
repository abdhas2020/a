/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const { MessageEmbed } = require('discord.js');
const ChildLogger = require('leekslazylogger').ChildLogger;
const log = new ChildLogger();

module.exports = {
	name: 'del-warn',
	description: 'deletes the warn for the @user',
	usage: '<@member>',
	aliases: ['none'],
	example: 'del-warn @abdi',
	args: false,
	async execute(client, message, args, {config, Ticket}) {
    console.log('[][]hello')
  }
}