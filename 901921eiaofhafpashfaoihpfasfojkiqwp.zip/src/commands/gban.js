/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const fs = require('fs');
const {
	MessageEmbed
} = require('discord.js');

module.exports = {
	name: 'gban',
	description: 'Gbans the @user',
	usage: '',
	aliases: ['globalban', 'gb'],
	example: 'gban Abdi',
	args: true,
	async execute(client, message, args, {config, Ticket}) {
    if (message.author.id !== '611553719972003860' && !message.member.roles.cache.has('745311606656729252')) 
			return message.channel.send(
				new MessageEmbed()
					.setColor(config.err_colour)
					.setAuthor(message.author.username, message.author.displayAvatarURL())
					.setTitle(':x: **No permission**')
					.setDescription(`You don't have permission to Use the Gban Command. This can only be Used By Network Adminstration!`)
					.addField('Usage', `\`${config.prefix}${this.name} ${this.usage}\`\n`)
					.addField('Help', `Type \`${config.prefix}help ${this.name}\` for more information`)
					.setFooter(message.guild.name, message.guild.iconURL())
			);
     let targetID = message.mentions.members.first();
      if (!targetID) {
        targetID = message.content.slice(message.content.indexOf(args[0]), message.content.length);
        
      }
      if(targetID == message.author.id) return message.channel.send('You cant gban your self');
      if(targetID == message.guild.me.id) return message.channel.send('Hahaha Dumb Boi im not gonna gban myself');
    
  let msg = await message.channel.send('Processing Gban')
  if(!targetID) {
    const id = message.mentions.members.first();
    const ida = id.id;
    targetID = id
  }
  let member = await message.channel.send(`<@${targetID}>`)
  const mention = member.mentions.members.first();
  mention.send(`You have been Global Banned From Exotic Network By ${message.author.tag}`)
message.client.guilds.cache.forEach(a => a.members.ban(targetID))
msg.delete()
member.delete()
  const embed = new MessageEmbed()
     .setTitle('Gban Successfull<a:check_122:767642060206374913>')
     .setColor('#FF0000')
     .addField('Target:', `${targetID}`)
     .addField('Executed From Guild:', `${message.guild.name}`, true)
     .addField('Executed From Channel:', `${message.channel.name}`, true)
     .setFooter(message.guild.name, message.guild.iconURL({ dynamic: true}))
     message.channel.send(embed)
     let jake = await message.channel.send('<@611553719972003860>')
     const men = jake.mentions.members.first();
     men.send(`${targetID} Just got Gbanned by ${message.author.tag}`)
     jake.delete()
  }
}