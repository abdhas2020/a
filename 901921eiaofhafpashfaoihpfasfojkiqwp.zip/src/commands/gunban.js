/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const fs = require('fs');
const {
	MessageEmbed
} = require('discord.js');

module.exports = {
	name: 'gunban',
	description: 'Gunbans the @user',
	usage: '',
	aliases: ['globalunban', 'gunb'],
	example: 'gunban 8190230203902',
	args: true,
	async execute(client, message, args, {config, Ticket}) {
     const targetID = message.content.slice(message.content.indexOf(args[0]), message.content.length);
     if (message.author.id !== '611553719972003860' && !message.member.roles.cache.has('745706706205540354')) 
			return message.channel.send(
				new MessageEmbed()
					.setColor(config.err_colour)
					.setAuthor(message.author.username, message.author.displayAvatarURL())
					.setTitle(':x: **No permission**')
					.setDescription(`You don't have permission to Use the Gunban Command. This can only be Used By Network Adminstration!`)
					.addField('Usage', `\`${config.prefix}${this.name} ${this.usage}\`\n`)
					.addField('Help', `Type \`${config.prefix}help ${this.name}\` for more information`)
					.setFooter(message.guild.name, message.guild.iconURL())
			);
    
  message.channel.send('Processing Gunban')
  if(!targetID) {
    const id = message.mentions.members.first();
    const ida = id.id;
    targetID = id
  }

message.client.guilds.cache.forEach(a => a.members.unban(targetID))
    message.channel.send('unBanned from all Servers <a:check_122:767642060206374913>')
    
  }
}