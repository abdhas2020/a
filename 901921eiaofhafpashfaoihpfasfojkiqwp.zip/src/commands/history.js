/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const { MessageEmbed } = require('discord.js');
const ChildLogger = require('leekslazylogger').ChildLogger;
const log = new ChildLogger();

module.exports = {
	name: 'history',
	description: 'Displays the warnings to the @user',
	usage: '<@member>',
	aliases: ['none'],
	example: 'history @abdi',
	args: false,
	async execute(client, message, args, {config, Ticket}) {
    console.log('[][]hello')
  }
}