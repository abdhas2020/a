/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const ChildLogger = require('leekslazylogger').ChildLogger;
const log = new ChildLogger();
const {
	MessageEmbed
} = require('discord.js');
const fs = require('fs');

module.exports = {
	name: 'intro',
	description: 'Intro for staff To Use',
	usage: '',
	aliases: ['in'],
	example: 'intro',
	args: false,
	async execute(client, message, args, {
		config,
		Ticket
	}) { 
      let member = message.mentions.members.first();
		// || client.channels.resolve(await Ticket.findOne({ where: { id: args[0] } }).channel) // channels.fetch()

		if (!member) {
			member = 'Sir Or Madam'
    }
    message.delete()
      const embed = new MessageEmbed()
      .setDescription(`Hello ${member}, Thank you for creating a ticket here at ${message.guild.name}. How can I help you today?`)
      .setThumbnail(message.guild.iconURL({ dynamic: true}))
      .setFooter(`Ticket Claimed By ${message.author.tag}`, message.author.displayAvatarURL())
      await message.channel.send(embed)
  }
}