/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const fs = require('fs');
const {
	MessageEmbed
} = require('discord.js');

module.exports = {
	name: 'kick',
	description: 'kicks the member from the server',
	usage: '',
	aliases: ['k'],
	example: 'kick Abdi',
	args: true,
  permission: 'KICK_MEMBERS',
	async execute(client, message, args, {config, Ticket}) {
    const member = message.mentions.members.first()
    if (member === message.member)
      return message.channel.send('You cannot kick yourself'); 
    if (!member.bannable)
      return message.channel.send('Provided member is not kickable');
 
    let reason = args.slice(1).join(' ');
    if (!reason) reason = '`None`';
    if (reason.length > 1024) reason = reason.slice(0, 1021) + '...';
    
    await member.kick(`Banned By + ${message.author.tag} Reason: ${reason}`);

    const embed = new MessageEmbed()
      .setTitle('kick Member')
      .setDescription(`${member} was successfully kicked.`)
      .addField('Moderator', message.member, true)
      .addField('Member', member, true)
      .addField('Reason', reason)
      .setFooter(message.member.displayName,  message.author.displayAvatarURL({ dynamic: true }))
      .setTimestamp()
      .setColor(message.guild.me.displayHexColor);
    message.channel.send(embed);
        
    // Update mod log
 message.client.channels.fetch('745337461881962638').then(channel => channel.send(embed))
  }
};
