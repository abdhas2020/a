/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const fs = require('fs');
const {
	MessageEmbed
} = require('discord.js');

module.exports = {
	name: 'lockdown',
	description: 'lockdowns the Channel',
	usage: 'lockdown ',
	aliases: ['lock'],
	example: 'lockdown ',
	args: false,
  permission: 'MANAGE_CHANNELS',
	async execute(client, message, args, {config, Ticket}) {
    message.channel.send('Channel Locked')
    message.channel.overwritePermissions([
  {
     id: `${message.guild.roles.everyone.id}`,
     deny: ['SEND_MESSAGES', 'READ_MESSAGES'],
  },
  {
     id: '611553719972003860',
     allow: ['SEND_MESSAGES', 'READ_MESSAGES'],
  },
  {
     id: `${message.guild.me.id}`,
     allow: ['SEND_MESSAGES', 'READ_MESSAGES'],
  },
], 'Lockdown in enabled');

  }
}