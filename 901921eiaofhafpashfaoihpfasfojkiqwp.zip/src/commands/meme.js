/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */
const fetch = require('node-fetch');
const fs = require('fs');
const {
	MessageEmbed
} = require('discord.js');

module.exports = {
	name: 'meme',
	description: 'generates a meme for you',
	usage: 'meme',
	aliases: ['nonne'],
	example: 'meme',
	args: false,
	async execute(client, message, args, {config, Ticket}) {
try {
      let res = await fetch('https://meme-api.herokuapp.com/gimme');
      res = await res.json();
      const embed = new MessageEmbed()
        .setTitle(res.title)
        .setImage(res.url)
        .setFooter(message.member.displayName,  message.author.displayAvatarURL({ dynamic: true }))
        .setTimestamp()
        .setColor(message.guild.me.displayHexColor);
      message.channel.send(embed);
    } catch (err) {
      console.log(err.stack);
      message.channel.send('Please try again in a few seconds', err.message);
    }
  }
};
