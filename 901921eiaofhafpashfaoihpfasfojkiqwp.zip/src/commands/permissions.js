
const { MessageEmbed } = require('discord.js');
const permissions = require('../permissions.json');
const { oneLine } = require('common-tags');

module.exports = {
	name: 'permissions',
	description: 'Displays all current permissions for the specified user.\n If no user is given, your own permissions will be displayed.',
	usage: 'permissions [user mention/ID]',
	aliases: ['perms'],
	example: 'perms @abdi',
	args: false,
	async execute(client, message, args, {config, Ticket}) {
    let member =  message.mentions.members.first();
    if (!member) {
      member = message.member;
    }

    // Get member permissions
    const memberPermissions = member.permissions.toArray();
    const finalPermissions = [];
    for (const permission in permissions) {
      if (memberPermissions.includes(permission)) finalPermissions.push(`+ ${permissions[permission]}`);
      else finalPermissions.push(`- ${permissions[permission]}`);
    }

    const embed = new MessageEmbed()
      .setTitle(`${member.displayName}'s Permissions`)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .setDescription(`\`\`\`diff\n${finalPermissions.join('\n')}\`\`\``)
      .setFooter(message.member.displayName, message.author.displayAvatarURL({ dynamic: true }))
      .setTimestamp()
      .setColor(member.displayHexColor);
    message.channel.send(embed);
  }
};