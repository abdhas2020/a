const { MessageEmbed } = require('discord.js');
const permissions = require('../permissions.json');
const { oneLine } = require('common-tags');

module.exports = {
	name: 'ping',
	description: 'Gets the bots latency',
	usage: 'ping',
	aliases: ['none'],
	example: 'ping',
	args: false,
	async execute(client, message, args, {config, Ticket}) {
    const embed = new MessageEmbed()
      .setDescription('`Pinging...`')
      .setColor(message.guild.me.displayHexColor);    
    const msg = await message.channel.send(embed);
    const timestamp = (message.editedTimestamp) ? message.editedTimestamp : message.createdTimestamp; // Check if edited
    const latency = `\`\`\`ini\n[ ${Math.floor(msg.createdTimestamp - timestamp)}ms ]\`\`\``;
    const apiLatency = `\`\`\`ini\n[ ${Math.round(message.client.ws.ping)}ms ]\`\`\``;
      const databaselat = `\`\`\`ini\n[ ${Math.round(1)}ms ]\`\`\``;
      embed.setTitle(`Pong!`)
      embed.setDescription('')
      embed.addField('Latency', latency, true)
      embed.addField('API Latency', apiLatency, true)
      embed.addField('Database Latency', databaselat, true)
      embed.setFooter(message.member.displayName,  message.author.displayAvatarURL({ dynamic: true }))
      .setTimestamp();
      msg.edit(embed);
  }
};
