/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const { MessageEmbed } = require('discord.js');
const ChildLogger = require('leekslazylogger').ChildLogger;
const log = new ChildLogger();

module.exports = {
	name: 'say',
	description: `Make the bot send a message in the current channel
  Options:

--embed to send the message as an embed.

--everyone enable everyone mentions in the message.

--vote add the voting reactions to the message.

--pin pins the message

--here adds a @here ping to the message`,
	usage: '<message>',
	aliases: ['none'],
	example: 'say --embed Hello ',
	args: false,
	async execute(client, message, args, {config, Ticket}) {
    let channel = message.mentions.channels.first();
    if(!channel) {
      channel = message.channel;
    }
    let msgArgs = message.content.split(" ");
    let isembed = args[0];
    let reason = (msgArgs[2]) ? message.content.substring(msgArgs.slice(0, 2).join(" ").length + 1) : "No Message provided";
    if(isembed == '--everyone') return channel.send(`${reason}
    
    
    
    - ${message.guild.roles.everyone}`);
    if(isembed == '--pin') {
      let msg = await message.channel.send(`${reason}`)
     await msg.pin();
     message.channel.bulkDelete(1)
    } else {
    if(isembed == '--here') return message.channel.send(`${reason}
    
- @here`)
    if(isembed == '--vote') {
      const votembed = new MessageEmbed()
      .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic: true}))
      .setDescription(reason)
      let voting = await channel.send(votembed)
      voting.react(message.guild.emojis.cache.get('771091549332176936'))
      voting.react(message.guild.emojis.cache.get('771091549207134229'))
      voting.react(message.guild.emojis.cache.get('771091548128804875'))
    } else {
    if(isembed !== '--embed') {
      let mess = (msgArgs[1]) ? message.content.substring(msgArgs.slice(0, 1).join(" ").length + 1) : "No reason provided";
      await channel.send(mess)
    }
      if(isembed == '--embed') {
    const embed = new MessageEmbed()
    .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic: true}))
    .setColor('#FF0000')
    .setDescription(reason)
    await channel.send(embed)
    }
    }
    }

  }
}