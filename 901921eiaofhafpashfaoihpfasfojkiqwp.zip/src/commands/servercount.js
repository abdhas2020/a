const { MessageEmbed } = require('discord.js');
const { stripIndent } = require('common-tags');

module.exports = {
	name: 'servercount',
	description: 'Fetches  server and user count.',
	usage: 'servercount',
	aliases: ['usercount', 'sc', 'uc'],
	example: 'servercount',
	args: false,
	async execute(client, message, args, {config, Ticket}) {
    const counts = stripIndent`
      Servers :: ${message.client.guilds.cache.size}
      Users   :: ${message.client.users.cache.size}
    `;
    const embed = new MessageEmbed()
      .setTitle('Server Count')
      .setDescription(stripIndent`\`\`\`asciidoc\n${counts}\`\`\``)
      .setFooter(message.member.displayName,  message.author.displayAvatarURL({ dynamic: true }))
      .setTimestamp()
      .setColor(message.guild.me.displayHexColor);
    message.channel.send(embed);
  }
};
