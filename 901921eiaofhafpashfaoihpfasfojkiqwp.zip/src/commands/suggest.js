/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const fs = require('fs');
const { Webhook, MessageBuilder } = require('discord-webhook-node');
const Discord = require('discord.js');
const hook = new Discord.WebhookClient('768924177642029058', 'ToPlFQYbf4-W9rHTaUhaMNB2kpnOf-eePB1LULzZwvuM1BZNf3fdFOMTktQpn89rIuF4');

module.exports = {
	name: 'suggest',
	description: 'this can be used for suggestions',
	usage: '<suggestion>',
	aliases: ['new-suggest'],
	example: 'suggest',
	args: true,
	async execute(client, message, args, {config, Ticket}) {
    let msgArgs = message.content.split(" ");
    let suggestion = (msgArgs[1]) ? message.content.substring(msgArgs.slice(0, 1).join(" ").length + 1) : "No Suggestion";
    const IMAGE_URL = message.author.displayAvatarURL();
hook.edit({
	name: message.author.username,
	avatar: IMAGE_URL,
})
const embed = new Discord.MessageEmbed();
embed.setDescription(`${suggestion}`)
embed.setTimestamp();
embed.setFooter('Powered By Exotic Network#4353')
webhookMessage = await hook.send('',
{ username: message.author.username,
 avatarURL: message.author.avatarURL,
 embeds: [embed] }); 
await webhookMessage.react('👍');
await webhookMessage.react('👎');
  }
}