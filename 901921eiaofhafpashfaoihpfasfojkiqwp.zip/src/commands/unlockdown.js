/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const fs = require('fs');
const {
	MessageEmbed
} = require('discord.js');

module.exports = {
	name: 'unlockdown',
	description: 'unlocks the Channel',
	usage: 'unlockdown ',
	aliases: ['unlock'],
	example: 'unlockdown ',
	args: false,
  permission: 'MANAGE_CHANNELS',
	async execute(client, message, args, {config, Ticket}) {
    message.channel.send('Channel unLocked')
    message.channel.overwritePermissions([
  {
     id: `${message.guild.roles.everyone.id}`,
     allow: ['SEND_MESSAGES'],
  },
  
], 'Lockdown in Disabled');
  }
}