/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const { MessageEmbed } = require('discord.js');
const ChildLogger = require('leekslazylogger').ChildLogger;
const log = new ChildLogger();

module.exports = {
	name: 'warn',
	description: 'warns the @user',
	usage: '<@member> <points> [reason]',
	aliases: ['none'],
	example: 'warn @abdi 2 spamming',
	args: false,
	async execute(client, message, args, {config, Ticket}) {
    console.log('[][]hello')
  }
}