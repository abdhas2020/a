/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const { Collection, MessageEmbed } = require('discord.js');
var words = require("naughty-words");
const Logger = require('leekslazylogger');
const log = new Logger();
const archive = require('../modules/archive');

module.exports = {
	event: 'message',
	async execute(client, [message], {config, Ticket, Setting}) {
   
 
		const guild = client.guilds.cache.get(config.guild);
    const bannedwords = ["bitch", "hore", "sex", "porn", "fuck me", "oh daddy", "test", "dick head", "fuck", "f*ck", "f*ck you", "shit", "asshole", "son of a b*tch", "bastard", "c*nt", "cunt", "choad"]
    var content = message.content;
    var stringToCheck = content.replace(/\s+/g, '').toLowerCase();

    for (var i = 0; i < bannedwords.length; i++) {
        if (content.includes(bannedwords[i])) {  
            message.delete();
            const noembed = new MessageEmbed()
            .setTitle('Exotic Network Police is Here 👮')
            .setColor('#FF0000')
            .addField(`Stop There Boi 🛑`, 'That Word is not allowed Here, Please Check your message Before sending them')
            .setFooter(message.author.tag, message.author.displayAvatarURL({ dynamic: true}))
            await message.channel.send(noembed);
        }
    }
    if(message.channel.id == '771091055596666882') {
      if(message.author.id == client.user.id) return;
      const sembed = new MessageEmbed()
      .setDescription(message)
      .setFooter(`Suggestion From ${message.author.tag}`, message.author.displayAvatarURL({ dynamic: true}))
      let suggest = await message.channel.send(sembed)
      suggest.react(message.guild.emojis.cache.get('771091549332176936'))
      suggest.react(message.guild.emojis.cache.get('771091549207134229'))
      suggest.react(message.guild.emojis.cache.get('771091548128804875'))
      message.delete()
    }
    const invitelinks = ["discord.gg/", "https://discord.gg/"]
    for (var i = 0; i < invitelinks.length; i++) {
      if(message.channel.parentID !== '745311737523339306' && '745311736856576050' && '745311736113922229') { 
        if (content.includes(invitelinks[i])) {  
          if(message.channel.parentID == '745706832378462319') return;
          if(message.channel.parentID == '745706832026402916') return;
          if(message.channel.topic == 'awaiting-basic-advertisment') return;
            message.delete();
            const noembed = new MessageEmbed()
            .setTitle('Exotic Network Police is Here 👮')
            .setColor('#FF0000')
            .setDescription(`Invite Links are not allowed 🛑`)
            .setFooter(message.author.tag, message.author.displayAvatarURL({ dynamic: true}))
            await message.channel.send(noembed);
            console.log(`[${message.channel.name}] Invite link was sent with this content - ${content}`)
        }
      }
    }
    if(message.channel.name == 'global-chat') {
      if(message.author.id == '769942285139443725') return;
      message.client.channels.fetch('770999464361852939').then(globalchat =>  globalchat.send(
        new MessageEmbed()
        .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic: true}))
      .setDescription(message.content)
      .setFooter(`Sent From ${message.guild.name}`, message.guild.iconURL())
      ))
      message.client.channels.fetch('771001988783276052').then(globalchat1 =>  globalchat1.send(
        new MessageEmbed()
        .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic: true}))
      .setDescription(message.content)
      .setFooter(`Sent From ${message.guild.name}`, message.guild.iconURL())
      ))
      message.delete()
      
    }
    	let text = config.tickets.text
      	.replace('{{ name }}', 'Sir or Madam')
				.replace('{{ tag }}', 'Sir or Madam');
        let basic = await message.client.channels.fetch('771033330099552278');
        let premium = await message.client.channels.fetch('771033356862619679');
        let ulti = await message.client.channels.fetch('771033394439389185')

  if(message.content == '1') {
    if(message.author.id !== message.client.user.id) return;
    message.delete()
    message.channel.bulkDelete(9);
    let w = await message.channel.send(
      new MessageEmbed()
      .setTitle('Partner Ticket')
      .setDescription(`
      Basic Partner \:five:
      Premium Partner \:six:
      Ultimate Partner \:seven:`)
      .setFooter(message.guild.name, message.guild.iconURL())
    )
    w.react('5️⃣')
    w.react('6️⃣')
    w.react('7️⃣')
  }
  if(message.content == '5') {
    if(message.author.id !== message.client.user.id) return;
    message.delete()
    message.channel.bulkDelete(1)
    let wa = await message.channel.send(
      new MessageEmbed()
      .setTitle('Basic Partner')
      .setDescription('Please Send your advertisment Below')
      .setFooter(message.guild.name, message.guild.iconURL())
    )
    message.channel.edit({ topic: 'awaiting-basic-advertisment' })
    message.channel.overwritePermissions([{
				id: guild.roles.everyone,
				deny: ['VIEW_CHANNEL', 'SEND_MESSAGES']
			},
			{
				id: client.user,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'ATTACH_FILES', 'READ_MESSAGE_HISTORY']
			},
			{
				id: message.member,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY', 'ADD_REACTIONS']
			}
			], '.');

  }
  if(message.content == '7') {
    if(message.author.id !== message.client.user.id) return;
    message.delete()
    message.channel.bulkDelete(1)
    let wa = await message.channel.send(
      new MessageEmbed()
      .setTitle('Ultimate Partner')
      .setDescription('Please Send your advertisment Below')
      .setFooter(message.guild.name, message.guild.iconURL())
    )
    message.channel.edit({ topic: 'awaiting-ulti-advertisment' })
    message.channel.overwritePermissions([{
				id: guild.roles.everyone,
				deny: ['VIEW_CHANNEL', 'SEND_MESSAGES']
			},
			{
				id: client.user,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'ATTACH_FILES', 'READ_MESSAGE_HISTORY']
			},
			{
				id: message.member,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY', 'ADD_REACTIONS']
			}
			], '.');

  }
  if(message.content == '6') {
  if(message.author.id !== message.client.user.id) return;
    message.delete()
    message.channel.bulkDelete(1)
    let wa = await message.channel.send(
      new MessageEmbed()
      .setTitle('Premium Partner')
      .setDescription('Please Send your advertisment Below')
      .setFooter(message.guild.name, message.guild.iconURL())
    )
    message.channel.edit({ topic: 'awaiting-premium-advertisment' })
    message.channel.overwritePermissions([{
				id: guild.roles.everyone,
				deny: ['VIEW_CHANNEL', 'SEND_MESSAGES']
			},
			{
				id: client.user,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'ATTACH_FILES', 'READ_MESSAGE_HISTORY']
			},
			{
				id: message.member,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY', 'ADD_REACTIONS']
			}
			], '.');

  }
  if(message.channel.topic == 'awaiting-basic-advertisment') {
    if (message.author.id == message.client.user.id) return;
    premium.send(
      new MessageEmbed()
      .setAuthor(`PartnerShip > ${message.author.tag}`, message.author.displayAvatarURL())
      .setDescription(message.content)
    )
    message.channel.overwritePermissions([{
				id: guild.roles.everyone,
				deny: ['VIEW_CHANNEL', 'SEND_MESSAGES']
			},
			{
				id: client.user,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'ATTACH_FILES', 'READ_MESSAGE_HISTORY']
			},
			{
 			  id: message.member,
				deny: ['SEND_MESSAGES']
			},
      {
        id: message.member,
        allow: ['VIEW_CHANNEL', 'READ_MESSAGE_HISTORY', 'ADD_REACTIONS']
      }
			], 'Advertisment sent');
      message.delete()
      message.channel.bulkDelete(1);
      let done = await message.channel.send(
        new MessageEmbed()
        .setDescription('Is there anything else i can help you with today?')
      )
      done.react('✅');

      done.react('❌');
      message.channel.edit( { topic: '.'})
     
  }
  if(message.channel.topic == 'awaiting-ulti-advertisment') {
    if (message.author.id == message.client.user.id) return;
    ulti.send(
      new MessageEmbed()
      .setAuthor(`PartnerShip > ${message.author.tag}`, message.author.displayAvatarURL())
      .setDescription(message.content)
    )
    message.channel.overwritePermissions([{
				id: guild.roles.everyone,
				deny: ['VIEW_CHANNEL', 'SEND_MESSAGES']
			},
			{
				id: client.user,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'ATTACH_FILES', 'READ_MESSAGE_HISTORY']
			},
			{
 			  id: message.member,
				deny: ['SEND_MESSAGES']
			},
      {
        id: message.member,
        allow: ['VIEW_CHANNEL', 'READ_MESSAGE_HISTORY', 'ADD_REACTIONS']
      }
			], '.');
      message.delete()
      message.channel.bulkDelete(1);
      let done = await message.channel.send(
        new MessageEmbed()
        .setDescription('Is there anything else i can help you with today?')
      )
      done.react('✅');

      done.react('❌');
      message.channel.edit( { topic: '.'})
     
  }
  if(message.channel.topic == 'awaiting-premium-advertisment') {
    if (message.author.id == message.client.user.id) return;
    premium.send(
      new MessageEmbed()
      .setAuthor(`PartnerShip > ${message.author.tag}`, message.author.displayAvatarURL())
      .setDescription(message.content)
    )
    message.channel.overwritePermissions([{
				id: guild.roles.everyone,
				deny: ['VIEW_CHANNEL', 'SEND_MESSAGES']
			},
			{
				id: client.user,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'ATTACH_FILES', 'READ_MESSAGE_HISTORY']
			},
			{
 			  id: message.member,
				deny: ['SEND_MESSAGES']
			},
      {
        id: message.member,
        allow: ['VIEW_CHANNEL', 'READ_MESSAGE_HISTORY', 'ADD_REACTIONS']
      }
			], '.');
      message.delete()
      message.channel.bulkDelete(1);
      let adone = await message.channel.send(
        new MessageEmbed()
        .setDescription('Is there anything else i can help you with today?')
      )
      adone.react('✅');

      adone.react('❌');
      message.channel.edit( { topic: '.'})
     
  }
  if(message.content == 'ddone') {
    if(message.author.id !== client.user.id) return;
    message.delete()
    message.channel.send('Have a good day')
    let delfastbebe = await message.channel.send('/close')
    delfastbebe.delete()
  }
  if(message.content == 'restart') {
    message.channel.bulkDelete(10)
    if(message.author.id !== client.user.id) return;
    let re = await message.channel.send(
				new MessageEmbed()
					.setColor(config.colour)
					.setAuthor(message.author.username, message.author.displayAvatarURL())
					.setDescription(`Please React to One of The Options
          Partner: \:one:
          Support:      \:two:
          Report:       \:three:
          Other:        \:four:`)
				 .setFooter('10 Seconds to Chose', message.guild.iconURL())
			);
      re.react('1️⃣')
      re.react('2️⃣')
      re.react('3️⃣')
      re.react('4️⃣')
  }
  if(message.content == '2') {
    if(message.author.id !== client.user.id) return;
    message.delete()
    message.channel.bulkDelete(2);
    message.channel.overwritePermissions([{
				id: guild.roles.everyone,
				deny: ['VIEW_CHANNEL', 'SEND_MESSAGES']
			},
			{
				id: client.user,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'ATTACH_FILES', 'READ_MESSAGE_HISTORY']
			},
			{
				id: message.member,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY', 'ADD_REACTIONS']
			}
			], '.');
      let supportembed = await message.channel.send(
        new MessageEmbed()
        .setTitle('Support Ticket')
        .setDescription(text)
        .setFooter(message.guild.name, message.guild.iconURL())

      )
      message.channel.send('@everyone').then(delbebe => delbebe.delete())
  }
      if(message.content == '3') {
        message.delete()
        message.channel.bulkDelete(2)
        message.channel.overwritePermissions([{
				id: guild.roles.everyone,
				deny: ['VIEW_CHANNEL', 'SEND_MESSAGES']
			},
			{
				id: client.user,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'ATTACH_FILES', 'READ_MESSAGE_HISTORY']
			},
			{
				id: message.member,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY', 'ADD_REACTIONS']
			}, 
      {
        id: '770972686787674114',
        allow: ['VIEW_CHANNEL','SEND_MESSAGES', 'READ_MESSAGE_HISTORY', 'ADD_REACTIONS']
      }
			], '.');
        let reportembed = await message.channel.send(
          new MessageEmbed()
          .setTitle('Report Ticket')
          .setDescription(`
Report Template
Please give us the following information:
Your Name:
Person reporting:
Person's ID:
Proof:
Staff Report
If you are reporting a staff member please head on over to our appeals server: [Network Appeals](https://exotic-network.gq/appeals)`)
        )

      }
      if(message.content == '4') {
        if(message.author.id !== client.user.id) return;
    message.delete()
    message.channel.bulkDelete(2);
    message.channel.overwritePermissions([{
				id: guild.roles.everyone,
				deny: ['VIEW_CHANNEL', 'SEND_MESSAGES']
			},
			{
				id: client.user,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'ATTACH_FILES', 'READ_MESSAGE_HISTORY']
			},
			{
				id: message.member,
				allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY', 'ADD_REACTIONS']
			}
			], '.');
      let supportembeda = await message.channel.send(
        new MessageEmbed()
        .setTitle('New Ticket')
        .setDescription(text)
        .setFooter(message.guild.name, message.guild.iconURL())

      )
      message.channel.send('@everyone').then(delbebe => delbebe.delete())
      }
      if (message.channel.type === 'dm') {
        if(message.author.id == client.user.id) return;
        const dmembed = new MessageEmbed()
         .setTitle('Please Chose a Server')
         .setDescription(`
         EN Bot Dev \:one:`)
         .setFooter('Ticket DM')
       let reactb = await message.reply(dmembed)
       reactb.react('1️⃣')

      }


  
 // stop here if is DM

		/**
		 * Ticket transcripts
		 * (bots currently still allowed)
		 */

		let ticket = await Ticket.findOne({ where: { channel: message.channel.id } });
		if (ticket) archive.add(message); // add message to archive



		/**
		 * Command handler
		 * (no bots / self)
		 */

		const regex = new RegExp(`^(<@!?${client.user.id}>|\\${config.prefix.toLowerCase()})\\s*`);
		if (!regex.test(message.content.toLowerCase())) return; // not a command

		const [, prefix] = message.content.toLowerCase().match(regex);
		const args = message.content.slice(prefix.length).trim().split(/ +/);
		const commandName = args.shift().toLowerCase();
		const command = client.commands.get(commandName)
			|| client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

		if (!command || commandName === 'none') return; // not an existing command

		if (command.permission && !message.member.hasPermission(command.permission)) {
			log.console(`${message.author.tag} tried to use the '${command.name}' command without permission`);
			return message.channel.send(
				new MessageEmbed()
					.setColor(config.err_colour)
					.setTitle(':x: No permission')
					.setDescription(`**You do not have permission to use the \`${command.name}\` command** (requires \`${command.permission}\`).`)
					.setFooter(guild.name, guild.iconURL())
			);
		}

		if (command.args && !args.length) {
			return message.channel.send(
				new MessageEmbed()
					.setColor(config.err_colour)
					.addField('Usage', `\`${config.prefix}${command.name} ${command.usage}\`\n`)
					.addField('Help', `Type \`${config.prefix}help ${command.name}\` for more information`)
					.setFooter(guild.name, guild.iconURL())
			);
		}

		if (!client.cooldowns.has(command.name)) client.cooldowns.set(command.name, new Collection());

		const now = Date.now();
		const timestamps = client.cooldowns.get(command.name);
		const cooldownAmount = (command.cooldown || config.cooldown) * 1000;

		if (timestamps.has(message.author.id)) {
			const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

			if (now < expirationTime) {
				const timeLeft = (expirationTime - now) / 1000;
				log.console(`${message.author.tag} attempted to use the '${command.name}' command before the cooldown was over`);
				return message.channel.send(
					new MessageEmbed()
						.setColor(config.err_colour)
						.setDescription(`:x: Please wait ${timeLeft.toFixed(1)} second(s) before reusing the \`${command.name}\` command.`)
						.setFooter(guild.name, guild.iconURL())
				);
			}
		}

		timestamps.set(message.author.id, now);
		setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);

		try {
			command.execute(client, message, args, {config, Ticket, Setting});
			log.console(`${message.author.tag} used the '${command.name}' command`);
		} catch (error) {
			log.warn(`An error occurred whilst executing the '${command.name}' command`);
			log.error(error);
			message.channel.send(`:x: An error occurred whilst executing the \`${command.name}\` command.`);
		}
	}
};