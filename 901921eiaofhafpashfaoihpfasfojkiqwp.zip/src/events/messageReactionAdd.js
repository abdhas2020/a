/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const Logger = require('leekslazylogger');
const log = new Logger();
const { MessageEmbed } = require('discord.js');
const fs = require('fs');
const { join } = require('path');

module.exports = {
	event: 'messageReactionAdd',
	async execute(client, [r, u], {config, Ticket, Setting}) {
		if (r.partial) {
			try {
				await r.fetch();
			} catch (err) {
				log.error(err);
				return;
			}
		}


		if (u.id === client.user.id) return;


		let channel = r.message.channel;

		// everything is cool

	if (r.emoji.name == '1️⃣') return channel.send('1');
  if (r.emoji.name == '2️⃣') return channel.send('2');
  if (r.emoji.name == '3️⃣') return channel.send('3');
  if (r.emoji.name == '4️⃣') return channel.send('4');
  if (r.emoji.name == '5️⃣') return channel.send('5');
   if (r.emoji.name == '6️⃣') return channel.send('6');
   if (r.emoji.name == '7️⃣') return channel.send('7');
   if (r.emoji.name == '❌') return channel.send('ddone');
  if (r.emoji.name == '✅') return channel.send('restart');
  
	}
};