/**
 *
 *  @name DiscordTickets
 *  @author eartharoid <contact@eartharoid.me>
 *  @license GNU-GPLv3
 *
 */

const ChildLogger = require('leekslazylogger').ChildLogger;
const log = new ChildLogger();
const config = require('../../user/' + require('../').config);

module.exports = {
	event: 'ready',
	execute(client) {
		log.success(`Authenticated as ${client.user.tag}`);
    client.user.setActivity('Exotic Network', { type: 'WATCHING' })

	


if (client.guilds.cache.get(config.guild).member(client.user).hasPermission('ADMINISTRATOR', false)) {
			log.success('\'ADMINISTRATOR\' permission has been granted');
		} else log.warn('Bot does not have \'ADMINISTRATOR\' permission');
	}
};
