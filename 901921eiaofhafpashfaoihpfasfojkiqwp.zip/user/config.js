/**
 * ###############################################################################################
 *  ____                                        _     _____              _             _
 * |  _ \  (_)  ___    ___    ___    _ __    __| |   |_   _| (_)   ___  | | __   ___  | |_   ___
 * | | | | | | / __|  / __|  / _ \  | '__|  / _` |     | |   | |  / __| | |/ /  / _ \ | __| / __|
 * | |_| | | | \__ \ | (__  | (_) | | |    | (_| |     | |   | | | (__  |   <  |  __/ | |_  \__ \
 * |____/  |_| |___/  \___|  \___/  |_|     \__,_|     |_|   |_|  \___| |_|\_\  \___|  \__| |___/
 *
 * ---------------------
 *      Quick Start
 * ---------------------
 *
 * 	> For detailed instructions, visit the GitHub repository and read the documentation:
 * 	https://github.com/eartharoid/DiscordTickets/wiki
 *
 * 	> IMPORTANT: Also edit the TOKEN in 'user/.env'
 *
 * ---------------------
 *       Support
 * ---------------------
 *
 * 	> Information: https://github.com/eartharoid/DiscordTickets/#readme
 * 	> Discord Support Server: https://go.eartharoid.me/discord
 * 	> Wiki: https://github.com/eartharoid/DiscordTickets/wiki
 *
 * ###############################################################################################
 */

module.exports = {
	prefix: '/',
	name: 'DiscordTickets',
	activities: [],
	activity_types: [], // Available: PLAYING / LISTENING / WATCHING / STREAMING
	colour: '#009999',
	err_colour: 'RED',
	cooldown: 3,

	guild: '770970796058607637', // ID of your guild
	staff_role: '770972686787674114', // ID of your Support Team role
  ticketban_role: '',

	tickets: {
		category: '770970835124879370', // ID of your tickets category
		send_img: false,
		ping: '',
		text: `Hello there, {{ tag }}!
		A member of staff will assist you shortly.
		In the mean time, please describe your issue in as much detail as possible! :)`,
		pin: true,
		max: 90
	},

	transcripts: {
		text: {
			enabled: true,
			keep_for: 90,
		},
		web: {
			enabled: true,
			server: 'http://localhost:8080',
		}
	},

	panel: {
		title: 'Support Tickets',
		description: 'React to create a Ticket',
		reaction: '🧾'
	},

	storage: {
		type: 'sqllite'
	},

	logs: {
		files: {
			enabled: true,
			keep_for: 14
		},
		discord: {
			enabled: true,
			channel: '770970853718097930' // ID of your log channel
		}
	},

	debug: true,
	updater: true
};
